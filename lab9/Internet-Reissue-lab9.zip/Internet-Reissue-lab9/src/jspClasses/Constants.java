package jspClasses;

public class Constants {
    public static final String URL1 = "URL1";
    public static final String URL2 = "URL2";
    public static final String URL_N = "URLn";

    public static final String VAL_1 = "val1";
    public static final String VAL_2 = "val2";
    public static final String VAL_3 = "val3";
    public static final String BEAN = "artCBean";

    public static final String Ttt_URL = "/Ttt";
    public static final String Ccc_URL = "/Ccc";

    public static final String PARAMETER_URL_NOT_FOUND = "Parameter Url not found";
}
